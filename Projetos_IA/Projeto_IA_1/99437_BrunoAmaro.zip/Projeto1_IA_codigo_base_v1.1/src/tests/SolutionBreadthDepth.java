package tests;

import graph_utils.*;
import search_algorithms.*;

public class SolutionBreadthDepth {
	public static void main(String[] args) {
		
		Graph g = new Graph();
		
		Node n1 = new Node("1");
		Node n2 = new Node("2");
		Node n3 = new Node("3");
		Node n4 = new Node("4");
		Node n5 = new Node("5");
		Node n6 = new Node("6");
		Node n7 = new Node("7");
		Node n8 = new Node("8");
		Node n9 = new Node("9");
		Node n10 = new Node("10");
		Node n11 = new Node("11");
		
		
		g.addEdge(n6, n10);
		g.addEdge(n10, n4);
		g.addEdge(n4, n3);
		g.addEdge(n3, n9);
		g.addEdge(n9, n7);
		g.addEdge(n9, n11);
		g.addEdge(n3, n11);
		g.addEdge(n4, n8);
		g.addEdge(n8, n5);
		g.addEdge(n5, n11);
		g.addEdge(n5, n2);
		g.addEdge(n5, n1);
		
		
		System.out.println("Initial node: " + n6.getLabel());
		System.out.println("Final node: " + n11.getLabel());
		System.out.println("----Largura----");
		SearchAlgorithm largura = new BreadthFirst(g);		
		largura.printResult(largura.startSearch(n6, n11));
		
		System.out.println();
		
		System.out.println("Initial node: " + n6.getLabel());
		System.out.println("Final node: " + n11.getLabel());
		System.out.println("----Profundidade----");
		SearchAlgorithm profundidade = new DepthFirst(g);		
		profundidade.printResult(profundidade.startSearch(n6, n11));
		
	}
}
