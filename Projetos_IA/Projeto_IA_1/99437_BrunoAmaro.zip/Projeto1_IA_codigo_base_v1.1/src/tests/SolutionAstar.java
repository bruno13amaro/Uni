package tests;

import graph_utils.*;
import search_algorithms.*;

public class SolutionAstar {
	public static void main(String[] args) {
		/*
		 * TO DO Aqui deves: 
		 * 		- criar a instancia do grafo que representa o mapa das
		 * 		masmorras (ver classe Exemplo.java) e explicar a funcao heuristica escolhida
		 * 		bem como os custos associados aos arcos (edges) 
		 * 		- colocar o c�digo para testar o algoritmo criado
		 * 
		 */
		
		/*
		 * Para o c�lculo dos custos o mapa foi dividido em pequenos quadrados que servem como a unidade de medida(ver figura mapa_dividido)
		 * G(N) -> � o numero total de quadrados que fazem parte do caminho real entre os quadrados centrais de dois n�s/salas 
		 * H(N) -> � a dist�ncia euclidiana entre os quadrados centrais de dois n�s/salas, para facilitar o seu c�lculo pode ser atribuida a cada
		 *         sala um conjunto de coordenadas (x,y) e a dist�ncia � dada pela dist�ncia entre coordenadas
		 *         � uma heuristica admissivel pois, por um lado o seu valor � sempre menor ou igual ao custo real da procura, e, por outro lado,
		 *         � independente do numero de salas que constituem o mapa
		 */
	
		
Graph g = new Graph();
		
		Node n1 = new Node("1",13);
		Node n2 = new Node("2",16);
		Node n3 = new Node("3",22);
		Node n4 = new Node("4",24);
		Node n5 = new Node("5",10);
		Node n6 = new Node("6",29);
		Node n7 = new Node("7",23);
		Node n8 = new Node("8",23);
		Node n9 = new Node("9",15);
		Node n10 = new Node("10",27);
		Node n11 = new Node("11",0);
		
		
		g.addEdge(n6, n10,8);
		g.addEdge(n10, n4,8);
		g.addEdge(n4, n3,24);
		g.addEdge(n3, n9,14);
		g.addEdge(n9, n7,18);
		g.addEdge(n9, n11,21);
		g.addEdge(n3, n11,30);
		g.addEdge(n4, n8,20);
		g.addEdge(n8, n5,24);
		g.addEdge(n5, n11,13);
		g.addEdge(n5, n2,22);
		g.addEdge(n5, n1,12);
		
		
		System.out.println("Initial node: " + n6.getLabel());
		System.out.println("Final node: " + n11.getLabel());
		System.out.println("----Astar----");
		SearchAlgorithm astar = new Astar(g);		
		astar.printResult(astar.startSearch(n6, n11));
	}
}
