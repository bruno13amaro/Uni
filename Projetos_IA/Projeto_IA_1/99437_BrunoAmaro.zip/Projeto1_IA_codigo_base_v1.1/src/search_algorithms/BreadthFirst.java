package search_algorithms;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;


import graph_utils.Edge;
import graph_utils.Graph;
import graph_utils.Node;

public class BreadthFirst extends SearchAlgorithm{

	//Lista que guarda os n�s visitados durante o processo de procura
	List<Node> nos_visitados = new ArrayList<>();
	//Variavel que indica quando o processo de obten��o do resultado deve come�ar
	private boolean parar = false;
	
	public BreadthFirst(Graph graph) {
		super(graph);
		
	}

	@Override
	//M�todo que realiza a procura e quando esta termina devolve o resultado se o n� final foi encontrado e null caso contr�rio
	public List<Node> start(Node n_initial, Node n_final) {
		Queue<Node> nos_gerados = new LinkedList<>();
		nos_gerados.offer(n_initial);
		while(!nos_gerados.isEmpty()) {
			expand(nos_gerados.poll(), n_final, nos_gerados);
			if(parar) return resultado(n_final, n_initial);
		}
		return null;
	}
	
	//M�todo que obt�m o resultado, indo do final at� ao n� inicial, fazendo sempre a escolha do caminho da solu��o 
	// a partir do metodo obterFather
	private List<Node> resultado(Node n_final, Node n_initial){
		List<Node> result = new ArrayList<>();
		while(!n_final.equals(n_initial)) {
			result.add(n_final);
			n_final = obterFather(n_final);
		}
		result.add(n_initial);
		Collections.reverse(result);
		return result;
	}
	
	//Metodo que devolve o n� que deu origem ao n� N
	private Node obterFather(Node n) {
		List<Node> aux = super.getFathers(n);
		if(aux.size() == 1)
			return aux.get(0);
		else 
			return bestFather(aux);
	}
	
	//Metodo que devolve o n� que deu origem ao n� n, e que faz parte da solu��o tendo em conta as caracteristicas do algoritmo
	private Node bestFather(List<Node> nodes) {
		int min = Integer.MAX_VALUE;
		for(Node n : nodes)
			if(nos_visitados.contains(n)) {
				int aux = nos_visitados.indexOf(n);
				if(aux < min)
					min = aux;
			}
		return nos_visitados.get(min);
	}
	
	//M�todo que faz o processo de expans�o, e que indica quando se deve come�ar o processo de obten��o do resultado
	private void expand(Node n, Node n_final, Queue<Node> nos_gerados) {
		nos_visitados.add(n);
		if(n.equals(n_final)) {
			parar = true;
			return;
		}
		List<Edge> aux = super.adjacencyOfNode(n);
		if(aux != null)
			for(Edge e : aux)
				nos_gerados.offer(e.getN1());
	}

}
