package search_algorithms;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Queue;
import graph_utils.Edge;
import graph_utils.Graph;
import graph_utils.Node;

public class Astar extends SearchAlgorithm{
	
	//Lista que guarda os n�s visitados durante o processo de procura
	private List<Node> nos_visistados = new ArrayList<>();
	//Variavel que indica quando o processo de obten��o do resultado deve come�ar
	private boolean parar = false;

	public Astar(Graph graph) {
		super(graph);
		// TODO Auto-generated constructor stub
	}

	@Override
	//M�todo que realiza a procura e quando esta termina devolve o resultado se on n� final foi encontrado e null caso contr�rio
	public List<Node> start(Node n_initial, Node n_final) {
		Queue<Node> nos_gerados = new PriorityQueue<>((n1,n2) -> n1.getF() - n2.getF());
		nos_gerados.offer(n_initial);
		while(!nos_gerados.isEmpty()) {
			expand(nos_gerados.poll(), n_final, nos_gerados);
			if(parar) return resultado(n_final, n_initial);
		}
		return null;
	}
	
	//M�todo que faz o processo de expans�o, e que indica quando se deve come�ar o processo de obten��o do resultado
	private void expand(Node n, Node n_final, Queue<Node> nos_gerados) {
		nos_visistados.add(n);
		if(n.equals(n_final)) {
			parar = true;
			return;
		}
		List<Edge> aux = super.adjacencyOfNode(n);
		if(aux != null)
			for(Edge e : aux)
				nos_gerados.offer(e.getN1());
	}
	
	//M�todo que obt�m o resultado, indo do final at� ao n� inicial, fazendo sempre a escolha do caminho da solu��o 
	// a partir do metodo obterFather
	private List<Node> resultado(Node n_final, Node n_initial){
		List<Node> result = new ArrayList<>();
		while(!n_final.equals(n_initial)) {
			result.add(n_final);
			n_final = obterFather(n_final);
		}
		result.add(n_initial);
		Collections.reverse(result);
		return result;
	}
	
	//Metodo que devolve o n� que deu origem ao n� N
	private Node obterFather(Node n) {
		List<Node> aux = super.getFathers(n);
		if(aux.size() == 1)
			return aux.get(0);
		else
			return bestFather(aux);
	}
	
	//Metodo que devolve o n� que deu origem ao n� n, e que faz parte da solu��o tendo em conta as caracteristicas do algoritmo
	private Node bestFather(List<Node> aux) {
		int max = Integer.MIN_VALUE;
		for(Node n : aux)
			if(nos_visistados.contains(n)) {
				int i = nos_visistados.indexOf(n);
				if( max < i)
					max = i;
			}
		return nos_visistados.get(max);
	}
	
	
	

}
