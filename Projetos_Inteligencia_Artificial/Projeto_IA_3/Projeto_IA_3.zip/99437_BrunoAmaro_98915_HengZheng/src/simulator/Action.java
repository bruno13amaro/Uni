package simulator;

public enum Action {
	DESTROY, NO_ACTION, PICK_UP
}
