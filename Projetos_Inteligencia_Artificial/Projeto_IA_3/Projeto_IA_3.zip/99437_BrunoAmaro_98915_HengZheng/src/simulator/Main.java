package simulator;
import net.sourceforge.jFuzzyLogic.FIS;
import net.sourceforge.jFuzzyLogic.FunctionBlock;
import weka.classifiers.trees.J48;
import weka.core.Instances;
import weka.core.converters.ConverterUtils.DataSource;

public class Main {
	
	public static void main(String[] args) throws Exception {
		
		String fileFCL = "robotControl.fcl"; 
		FIS fis = FIS.load(fileFCL, true); 
		if (fis == null) { 
		   System.err.println("Can't load file: '" + fileFCL + "'"); 
		   System.exit(1); 
		}
		FunctionBlock fb = fis.getFunctionBlock(null);
		
		String fileARFF = "mushroom.arff";
		DataSource source = new DataSource(fileARFF); 
		Instances dataset = source.getDataSet(); 
		dataset.setClassIndex(dataset.numAttributes() - 1); 
		
		J48 classifier = new J48(); 
		classifier.buildClassifier(dataset);
		
		Simulator sim = new Simulator(); 
		
		sim.step();
		
		while(true)
			function(fb,sim,classifier,dataset);
		
	}
	 
	public static void function(FunctionBlock fb, Simulator sim, J48 classifier,Instances dataset) throws Exception{
		
		setValueFB(fb,sim, classifier, dataset);
		
		fb.evaluate();
		fb.getVariable("angle").defuzzify();
		fb.getVariable("action").defuzzify();
		
		sim.setRobotAngle(fb.getVariable("angle").getLatestDefuzzifiedValue());
		sim.setAction(obterAction((int)fb.getVariable("action").getLatestDefuzzifiedValue()));

		sim.step();
	}
	
	public static void setValueFB(FunctionBlock fb, Simulator sim,J48 classifier,Instances dataset) throws Exception{
		String s = "none";
		fb.setVariable("distance_right", sim.getDistanceR());
		fb.setVariable("distance_centre", sim.getDistanceC());
		fb.setVariable("distance_left", sim.getDistanceL());
		
		String[] a = sim.getMushroomAttributes();
		if(a != null) {
			NewInstances ni = new NewInstances(dataset);
			ni.addInstance(a);
			double predict = classifier.classifyInstance(ni.getDataset().lastInstance());
			s = dataset.classAttribute().value((int) predict);
		}
		
		fb.setVariable("mushroom_classification", obterClassificacao(s));
	}
	
	public static Action obterAction(int predict) {
		switch(predict){
		case -10:
			return Action.DESTROY;
		case 0:
			return Action.NO_ACTION;
		case 10:
			return Action.PICK_UP;
		default:
			throw new IllegalArgumentException();
	}}
	
	public static int obterClassificacao(String predict) {
		switch(predict) {
		case "poisonous":
			return -10;
		case "none":
			return 0;
		case "edible":
			return 10;
		default:
			throw new IllegalArgumentException();
		}
	}
	
}




